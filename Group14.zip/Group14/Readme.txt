Utviklere/ Group 14: 
Philip Toan Nguyen and Sindre Salverød.
Prosjektbeskrivelse:
GameStop is a video game and gaming merchandise retailer. We’ve “made” a website for GameStop. Though all GameStop shops are closed in Norway, this website is based on the GameStop shop that was in Porsgrunn before it closed. We pretended to build a website for a GameStop shop in Porsgrunn, which is meant to be used by the local people. This website is not an e-commerce, but for giving information and oppurtunity to contact the store. This website is necessarily not only for the local people, but also for others from other counties in Norway who wants to visit Gamestop in Porsgrunn. 
Web design:
Our goal from the start was to make the website simple, clean and easy to use. We ended up with this design because of those principles, and we were certainly inspired by other websites with similar looks/styles. 
Hvordan implementerte dere løsningene?
We’ve been using prototype. We drew how our website is supposed to look like. It didn’t take long time before we came to an agreement. 
We were cooperative overall working with this website. We also helped each other when needed, and while there were challenges involved in the task, we managed to overcome them with good communication. 
Teknologi brukt for implementasjon:
We’ve used mostly HTML5 and CSS. Validation is used in skjema with Javascript.